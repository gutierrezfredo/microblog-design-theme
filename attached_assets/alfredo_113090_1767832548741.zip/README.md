# Micro.blog Open External Links

A Micro.blog plugin to open all external links in a new browser tab or window automatically.

![](https://raw.githubusercontent.com/jimmitchell/plugin-external-links/main/logo.jpg)