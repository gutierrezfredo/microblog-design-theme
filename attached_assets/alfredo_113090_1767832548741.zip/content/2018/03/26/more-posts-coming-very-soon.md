---
layout: post
title: "More posts coming very soon!"
microblog: false
guid: http://alfredo.micro.blog/2018/03/26/more-posts-coming-very-soon.html
post_id: 5682166
custom_summary: false
summary: ""
date: 2018-03-26T13:37:00-0600
lastmod: 2025-12-28T16:12:21-0600
type: post
categories:
- "logs"
thumbnail: https://s3.amazonaws.com/micro.blog/thumbnails/2025/12/24/alfredo.design/41177f92c116eafc402797739e77a002.png
opengraph:
  title: "Alfredo Gutierrez - More posts coming very soon!"
  image: https://s3.amazonaws.com/micro.blog/opengraph/2025/12/24/5682166.png
url: "/2018/03/26/more-posts-coming-very-soon.html"
---

I'm currently working on this section and getting ready a couple of blog posts about UX design, tools, and productivity
