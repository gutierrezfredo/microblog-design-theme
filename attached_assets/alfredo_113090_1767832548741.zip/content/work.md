---
title: "Work"
navigation: true
menu: main
weight: 1
date: 2025-12-28T16:58:14-0600
url: /work/
---

<!-- Redirecs to home | Config in theme -->
