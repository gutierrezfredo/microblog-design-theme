---
title: "Social"
navigation: false
date: 2025-12-29T20:21:55-0600
url: /social/
---

<a href="/contact"><i class="ph ph-envelope"></i></a>
<a href="https://linkedin.com/in/gutifredo"><i class="ph ph-linkedin-logo"></i></a>
<a href="https://mastodon.design/@alfredo"><i class="ph ph-mastodon-logo"></i></a>
<a href="https://bsky.app/profile/alfredo.design"><i class="ph ph-butterfly"></i></a>
