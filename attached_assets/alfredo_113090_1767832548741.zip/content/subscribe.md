---
title: "Subscribe"
navigation: true
menu: main
weight: 11
date: 2025-12-28T16:58:10-0600
url: /subscribe/
---

Subscribe to the email newsletter for this blog.

<form method="POST" action="https://micro.blog/users/subscribe/281589">
  <input type="text" name="email" size="30" placeholder="Your email address" /> 
  <input type="submit" value="Subscribe" />
</form>
