---
title: "Intro"
navigation: false
date: 2026-01-02T21:51:33-0600
url: /intro/
---

![profile.png](https://alfredo.design/uploads/2025/16e37fd268.png)

<h1><span>hey!</span> <span>Alfredo</span> <span>here</span></h1>
## A Product Designer

Creating digital products for startups and designing websites that support brands' marketing strategies.
